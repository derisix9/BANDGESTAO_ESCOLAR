#!/usr/bin/env bash
# Corre as migrações e os testes de segurança (RLS) e de backup/restauro num Postgres local descartável.
# Requer: psql e um servidor Postgres acessível (variável PGURL, ex.: postgres://postgres:postgres@localhost:5432/postgres)
set -euo pipefail
PGURL="${PGURL:-postgres://postgres:postgres@localhost:5432/postgres}"
DB=bm_test_$$
psql "$PGURL" -q -c "create database $DB"
URL="${PGURL%/*}/$DB"
trap 'psql "$PGURL" -q -c "drop database if exists $DB" >/dev/null' EXIT
psql "$URL" -q -v ON_ERROR_STOP=1 -c 'create schema if not exists extensions' -c 'create extension if not exists pgcrypto with schema extensions'
psql "$URL" -q -v ON_ERROR_STOP=1 -f supabase/tests/00_local_auth_stub.sql
for f in supabase/migrations/*.sql; do echo "→ $f"; psql "$URL" -q -v ON_ERROR_STOP=1 -f "$f"; done
OUT=$(psql "$URL" -f supabase/tests/rls.test.sql)
echo "$OUT" | tail -12
echo "$OUT" | grep -qE '^\s+[0-9]+ \|\s+0$' || { echo "TESTES DE SEGURANÇA FALHARAM"; exit 1; }
# Backup/restauro por escola em ficheiro (0012)
OUT=$(psql "$URL" -f supabase/tests/school_backup.test.sql)
echo "$OUT" | tail -14
echo "$OUT" | grep -qE '^\s+[0-9]+ \|\s+0$' || { echo "TESTES DE BACKUP/RESTAURO FALHARAM"; exit 1; }
# Eliminação de dados da escola (0015 + 0016)
OUT=$(psql "$URL" -f supabase/tests/school_delete.test.sql)
echo "$OUT" | tail -14
echo "$OUT" | grep -qE '^\s+[0-9]+ \|\s+0$' || { echo "TESTES DE ELIMINAÇÃO FALHARAM"; exit 1; }
# Filiais: escola mãe + filiais, escola ativa do administrador, isolamento (0024)
OUT=$(psql "$URL" -f supabase/tests/branches.test.sql)
echo "$OUT" | tail -14
echo "$OUT" | grep -qE '^\s+[0-9]+ \|\s+0$' || { echo "TESTES DE FILIAIS FALHARAM"; exit 1; }
# Pagamentos automáticos por referência: idempotência, parcial, duplicados, isolamento entre escolas, permissões (0038)
OUT=$(psql "$URL" -f supabase/tests/payments_gateway.test.sql)
echo "$OUT" | tail -14
echo "$OUT" | grep -qE '^\s+[0-9]+ \|\s+0$' || { echo "TESTES DE PAGAMENTOS POR REFERÊNCIA FALHARAM"; exit 1; }
# Notificações por escola: configuração por canal, isolamento, permissões, fila com categoria, workers e quem recebe cada push (0039)
OUT=$(psql "$URL" -f supabase/tests/notifications_gateway.test.sql)
echo "$OUT" | tail -14
echo "$OUT" | grep -qE '^\s+[0-9]+ \|\s+0$' || { echo "TESTES DE NOTIFICAÇÕES POR ESCOLA FALHARAM"; exit 1; }
# Bloqueio de login no servidor: hook de verificação de palavra-passe, reincidência, isolamento, permissões (0042)
OUT=$(psql "$URL" -f supabase/tests/login_lockout.test.sql)
echo "$OUT" | tail -14
echo "$OUT" | grep -qE '^\s+[0-9]+ \|\s+0$' || { echo "TESTES DE BLOQUEIO DE LOGIN FALHARAM"; exit 1; }
# Monitorização de erros do cliente: agrupamento, truncagem, anti-inundação, isolamento, permissões (0047)
OUT=$(psql "$URL" -f supabase/tests/client_errors.test.sql)
echo "$OUT" | tail -14
echo "$OUT" | grep -qE '^\s+[0-9]+ \|\s+0$' || { echo "TESTES DE MONITORIZAÇÃO DE ERROS FALHARAM"; exit 1; }
# Lista de IPs autorizados no servidor: normalização, RLS, fail-closed, anti-bloqueio, filiais, Edge Functions (0043)
OUT=$(psql "$URL" -f supabase/tests/ip_allowlist.test.sql)
echo "$OUT" | tail -14
echo "$OUT" | grep -qE '^\s+[0-9]+ \|\s+0$' || { echo "TESTES DA LISTA DE IPs FALHARAM"; exit 1; }
# Registo nativo do Supabase Auth: e-mails descartáveis, só com e-mail confirmado cria a escola, idempotência, permissões (0046)
OUT=$(psql "$URL" -f supabase/tests/registo_nativo.test.sql)
echo "$OUT" | tail -14
echo "$OUT" | grep -qE '^\s+[0-9]+ \|\s+0$' || { echo "TESTES DO REGISTO NATIVO FALHARAM"; exit 1; }
# Palavra-passe temporária e validade no servidor: bloqueio da RLS, trigger do Auth, política, forçar troca, Edge Functions (0045)
OUT=$(psql "$URL" -f supabase/tests/password_policy.test.sql)
echo "$OUT" | tail -14
echo "$OUT" | grep -qE '^\s+[0-9]+ \|\s+0$' || { echo "TESTES DE PALAVRA-PASSE FALHARAM"; exit 1; }
