/**
 * Servidor de notificações (passo 5) — worker GLOBAL (um fornecedor para todas as escolas que não ligaram o SEU).
 *
 * As escolas que ligaram o próprio fornecedor em Configurações → Integrações → Notificações (migração 0039) são servidas pela
 * Edge Function `notifications` e o claim_notifications() já não lhes dá mensagens: não há envios duplicados.
 *
 * Fornecedores por VARIÁVEL DE AMBIENTE (interfaces SmsProvider / WhatsAppProvider em supabase/functions/_shared/notify.ts):
 *   SMS_PROVIDER = twilio (omissão) | infobip | http          WHATSAPP_PROVIDER = twilio (omissão) | meta_cloud
 *   twilio    TWILIO_ACCOUNT_SID, TWILIO_AUTH_TOKEN, TWILIO_SMS_FROM  (ou TWILIO_MESSAGING_SERVICE_SID)
 *   infobip   INFOBIP_BASE_URL (https://xxxx.api.infobip.com), INFOBIP_API_KEY, INFOBIP_SENDER
 *   http      agregador LOCAL por API genérica: SMS_HTTP_URL, SMS_HTTP_BODY_TEMPLATE (ex.: {"to":"{{to}}","text":"{{message}}"}),
 *             opcionais SMS_HTTP_CONTENT_TYPE (json|form), SMS_HTTP_AUTH_MODE (none|bearer|basic|header|query), SMS_HTTP_AUTH_NAME,
 *             SMS_HTTP_TOKEN, SMS_HTTP_PHONE_FORMAT (e164|digits|local), SMS_HTTP_SENDER, SMS_HTTP_SUCCESS_CONTAINS
 *   WhatsApp  twilio: TWILIO_WHATSAPP_FROM + TWILIO_WHATSAPP_CONTENT_SID (modelo aprovado)  |  meta_cloud: META_PHONE_NUMBER_ID,
 *             META_ACCESS_TOKEN, META_TEMPLATE_NAME, META_TEMPLATE_LANG (pt_PT), META_API_VERSION (v21.0)
 *   WhatsApp em produção SÓ com modelo aprovado. Sem TWILIO_WHATSAPP_CONTENT_SID envia texto livre (só serve no sandbox do Twilio).
 * Regra de uso: SMS só para avisos CRÍTICOS (ex.: propina em atraso) — SMS_CRITICAL_ONLY=false desliga a regra. Push é grátis e fica na app.
 *
 * Corra com:   npx tsx server/notify.ts
 * Outras variáveis (nunca no código nem no repositório):
 *   SUPABASE_URL, SUPABASE_ANON_KEY (NUNCA a service_role), NOTIFY_ALLOWED_EMAILS, NOTIFY_ALLOWED_ORIGIN,
 *   SUPABASE_SERVICE_ROLE_KEY (opcional: modo fila, só no servidor), NOTIFY_POLL_SECONDS (omissão 15), NOTIFY_PORT (8787)
 *
 * Dois modos:
 *   - COM SUPABASE_SERVICE_ROLE_KEY (modo fila, recomendado): POST /notify só ENFILEIRA em public.notification_queue (com o token de
 *     quem pede, por isso a RLS aplica a permissão e a escola). Um worker reserva lotes com claim_notifications(), envia e regista o
 *     resultado com finish_notification(). Falhas repetem com recuo (2, 4, 8... min, até 5 tentativas). "Aceite" não é "entregue".
 *   - SEM essa chave (modo directo): envia logo e responde com o resultado.
 * A cada pedido aceita no máximo 500 mensagens.
 */
import express from 'express';
import type { GatewayMessage, GatewayResult } from '../src/utils/notificationGateway';
import { toE164 } from '../src/utils/notificationGateway';
import { NotifyError, cleanCategory, safeNotifyMessage, smsBlockedReason, type SmsProvider, type WhatsAppProvider } from '../supabase/functions/_shared/notify';
import { buildProvidersFromEnv } from './notifyEnv';

// Lê o ficheiro .env da pasta onde corre o comando (não substitui variáveis já definidas no sistema).
try { (process as any).loadEnvFile?.(); } catch { /* sem .env: usa só as variáveis do sistema */ }

const env = (k: string) => process.env[k] || '';
const MAX_MESSAGES = 500;

/** Valida o token de sessão Supabase (access_token) e devolve o e-mail de quem pede. */
async function verifyIdToken(accessToken: string): Promise<{ email?: string } | null> {
  const url = env('SUPABASE_URL').replace(/\/+$/, '');
  const key = env('SUPABASE_ANON_KEY');
  if (!url || !key) return null;
  try {
    const res = await fetch(`${url}/auth/v1/user`, {
      headers: { apikey: key, Authorization: `Bearer ${accessToken}` }
    });
    if (!res.ok) return null;
    const user = (await res.json()) as { email?: string };
    return user?.email ? { email: user.email.toLowerCase() } : null;
  } catch {
    return null;
  }
}

const PROVIDERS = buildProvidersFromEnv();
const SMS_CRITICAL_ONLY = env('SMS_CRITICAL_ONLY').toLowerCase() !== 'false';

/** Envia UMA mensagem pelo fornecedor escolhido por variável de ambiente. Nunca lança. */
async function sendMessage(m: Omit<GatewayMessage, 'category'> & { category?: string }): Promise<GatewayResult & { retryable?: boolean }> {
  if (m.channel === 'sms') {
    const blocked = smsBlockedReason(cleanCategory(m.category), SMS_CRITICAL_ONLY);
    if (blocked) return { id: m.id, ok: false, error: blocked, retryable: false };
  }
  const to = toE164(m.to);
  if (!to) return { id: m.id, ok: false, error: 'Número inválido.', retryable: false };
  const p = m.channel === 'whatsapp' ? PROVIDERS.whatsapp : PROVIDERS.sms;
  if (!p) return { id: m.id, ok: false, error: (m.channel === 'whatsapp' ? PROVIDERS.whatsappError : PROVIDERS.smsError) || 'Fornecedor não configurado no servidor.', retryable: false };
  try {
    const attachment = m.channel === 'whatsapp' && m.attachment?.url ? { url: m.attachment.url, filename: m.attachment.filename || 'documento.pdf' } : undefined;
    const r = m.channel === 'whatsapp' ? await (p as WhatsAppProvider).sendTemplate({ id: m.id, to, text: m.body, ...(attachment ? { attachment } : {}) }) : await (p as SmsProvider).send({ id: m.id, to, text: m.body });
    return { id: m.id, ok: true, providerId: r.providerId };
  } catch (e) {
    return { id: m.id, ok: false, error: safeNotifyMessage(e), retryable: e instanceof NotifyError ? e.retryable : true };
  }
}

const SERVICE_KEY = env('SUPABASE_SERVICE_ROLE_KEY');
const QUEUE_MODE = Boolean(SERVICE_KEY);
const supaUrl = () => env('SUPABASE_URL').replace(/\/+$/, '');

interface QueueRow { id: string; channel: 'sms' | 'whatsapp'; to_phone: string; body: string; category?: string; attempts?: number; attachment_url?: string | null; attachment_name?: string | null }

/** Chamada RPC com a chave service_role (só o worker). */
async function rpcService<T>(fn: string, args: Record<string, unknown>): Promise<T> {
  const res = await fetch(`${supaUrl()}/rest/v1/rpc/${fn}`, {
    method: 'POST',
    headers: { apikey: SERVICE_KEY, Authorization: `Bearer ${SERVICE_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify(args)
  });
  if (!res.ok) throw new Error(`${fn}: HTTP ${res.status} ${(await res.text().catch(() => '')).slice(0, 200)}`);
  const text = await res.text();
  return (text ? JSON.parse(text) : null) as T;
}

let draining = false;
/** Reserva um lote, envia e regista o resultado. Nunca lança; repete no próximo ciclo. */
async function drainQueue(): Promise<void> {
  if (draining) return;
  draining = true;
  try {
    for (;;) {
      const rows = await rpcService<QueueRow[]>('claim_notifications', { p_limit: 50 });
      if (!rows || rows.length === 0) break;
      for (const r of rows) {
        const out = await sendMessage({ id: r.id, to: r.to_phone, channel: r.channel, body: r.body, category: r.category, ...(r.attachment_url ? { attachment: { url: r.attachment_url, filename: r.attachment_name || 'documento.pdf' } } : {}) });
        if (!out.ok && out.retryable === false) {   // falha definitiva (regra do SMS, número, configuração): não repete
          try { await rpcService('notification_skip', { p_id: r.id, p_reason: out.error ?? 'recusada' }); }
          catch { try { await rpcService('finish_notification', { p_id: r.id, p_ok: false, p_provider_id: null, p_error: out.error ?? null }); } catch { /* requeue_stuck */ } }
          continue;
        }
        try {
          await rpcService('finish_notification', { p_id: r.id, p_ok: out.ok, p_provider_id: out.providerId ?? null, p_error: out.error ?? null });
        } catch (e) {
          // Se não conseguir registar, a mensagem fica "a enviar" e a tarefa bm_requeue_stuck volta a pô-la na fila.
          console.error('Falha a registar resultado', r.id, e instanceof Error ? e.message : e);
        }
      }
    }
  } catch (e) {
    console.error('Worker da fila:', e instanceof Error ? e.message : e);
  } finally {
    draining = false;
  }
}

/** Enfileira com o token de quem pede: a RLS garante permissão e escola; o servidor não escolhe a escola. */
async function enqueueAsUser(accessToken: string, messages: GatewayMessage[]): Promise<GatewayResult[]> {
  const base = supaUrl();
  const headers = { apikey: env('SUPABASE_ANON_KEY'), Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' };
  const fail = (error: string) => messages.map((m) => ({ id: m.id, ok: false, error }));
  try {
    const u = await fetch(`${base}/auth/v1/user`, { headers });
    const uid = u.ok ? ((await u.json()) as { id?: string }).id : undefined;
    if (!uid) return fail('Sessão inválida.');
    const p = await fetch(`${base}/rest/v1/profiles?id=eq.${encodeURIComponent(uid)}&select=institution_id,role,active_institution_id`, { headers });
    const prof = p.ok ? ((await p.json()) as Array<{ institution_id?: string; role?: string; active_institution_id?: string | null }>)[0] : undefined;
    // Só o administrador pode estar numa filial; a escola ativa vem do perfil (o servidor valida na migração 0024).
    const inst = prof?.role === 'admin' && prof.active_institution_id ? prof.active_institution_id : prof?.institution_id;
    if (!inst) return fail('Perfil sem escola associada.');

    const rows: Array<{ institution_id: string; channel: string; to_phone: string; body: string; category: string; attachment_url?: string; attachment_name?: string }> = [];
    const keep: GatewayMessage[] = [];
    const results = new Map<string, GatewayResult>();
    for (const m of messages) {
      const to = toE164(m.to);
      if (!to) { results.set(m.id, { id: m.id, ok: false, error: 'Número inválido.' }); continue; }
      const category = cleanCategory(m.category);
      const blocked = m.channel === 'sms' ? smsBlockedReason(category, SMS_CRITICAL_ONLY) : null;
      if (blocked) { results.set(m.id, { id: m.id, ok: false, error: blocked }); continue; }
      // Só o link público da função meeting-file do próprio projecto é aceite como anexo.
      const okAtt = m.channel === 'whatsapp' && m.attachment?.url && m.attachment.url.startsWith(`${base}/functions/v1/meeting-file?`) && m.attachment.url.length <= 400;
      rows.push({ institution_id: inst, channel: m.channel, to_phone: to, body: m.body, category, ...(okAtt ? { attachment_url: m.attachment!.url, attachment_name: String(m.attachment!.filename || 'documento.pdf').replace(/[^\w .()-]+/g, '_').slice(0, 120) } : {}) });
      keep.push(m);
    }
    if (rows.length) {
      const ins = await fetch(`${base}/rest/v1/notification_queue`, { method: 'POST', headers: { ...headers, Prefer: 'return=minimal' }, body: JSON.stringify(rows) });
      const err = ins.ok ? '' : `Fila recusou o pedido (HTTP ${ins.status}).`;
      for (const m of keep) results.set(m.id, err ? { id: m.id, ok: false, error: err } : { id: m.id, ok: true, providerId: 'fila' });
    }
    return messages.map((m) => results.get(m.id) as GatewayResult);
  } catch (e) {
    return fail(e instanceof Error ? e.message : 'erro de rede');
  }
}

const app = express();
app.use(express.json({ limit: '1mb' }));
app.use((req, res, next) => {
  const origin = env('NOTIFY_ALLOWED_ORIGIN');
  if (origin) {
    res.setHeader('Access-Control-Allow-Origin', origin);
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  }
  if (req.method === 'OPTIONS') return res.sendStatus(204);
  next();
});

app.post('/notify', async (req, res) => {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const who = token ? await verifyIdToken(token) : null;
  const allowed = env('NOTIFY_ALLOWED_EMAILS').toLowerCase().split(',').map((s) => s.trim()).filter(Boolean);
  if (!who?.email || !allowed.includes(who.email)) return res.status(403).send('Não autorizado.');

  const messages = (req.body?.messages || []) as GatewayMessage[];
  if (!Array.isArray(messages) || messages.length === 0 || messages.length > MAX_MESSAGES) {
    return res.status(400).send(`Envie entre 1 e ${MAX_MESSAGES} mensagens.`);
  }
  const valid = messages.every((m) => m && typeof m.id === 'string' && typeof m.body === 'string' && m.body.length <= 480 && (m.channel === 'sms' || m.channel === 'whatsapp'));
  if (!valid) return res.status(400).send('Pedido inválido.');

  if (QUEUE_MODE) {
    const results = await enqueueAsUser(token, messages);
    void drainQueue(); // arranca já um ciclo, sem esperar pelo próximo intervalo
    return res.json({ results });
  }
  const results: GatewayResult[] = [];
  for (const m of messages) { const { retryable: _r, ...res } = await sendMessage(m); results.push(res); } // em série: evita estourar limites do fornecedor
  res.json({ results });
});

const port = Number(env('NOTIFY_PORT')) || 8787;
app.listen(port, () => {
  console.log(`Gateway de notificações em http://localhost:${port}/notify (${QUEUE_MODE ? 'modo fila' : 'modo directo'})`);
  // Diagnóstico: só mostra NOMES de variáveis em falta, nunca valores.
  const needed = ['SUPABASE_URL', 'SUPABASE_ANON_KEY', 'NOTIFY_ALLOWED_EMAILS', 'NOTIFY_ALLOWED_ORIGIN'];
  const missing = needed.filter((k) => !env(k));
  if (!QUEUE_MODE) {
    missing.unshift('SUPABASE_SERVICE_ROLE_KEY');
    const alike = Object.keys(process.env).filter((k) => /service|role/i.test(k) && k !== 'SUPABASE_SERVICE_ROLE_KEY');
    if (alike.length) console.warn(`  Atenção: encontrei ${alike.map((k) => `"${k}"`).join(', ')}, mas o nome certo é SUPABASE_SERVICE_ROLE_KEY.`);
  }
  if (missing.length) console.warn(`  Variáveis em falta ou vazias: ${missing.join(', ')}`);
  console.log(`  SMS: ${PROVIDERS.sms ? PROVIDERS.sms.name : 'não configurado'}${SMS_CRITICAL_ONLY ? ' (só avisos críticos)' : ''}; WhatsApp: ${PROVIDERS.whatsapp ? PROVIDERS.whatsapp.name : 'não configurado'}`);
  if (PROVIDERS.smsError && env('SMS_PROVIDER')) console.warn(`  SMS: ${PROVIDERS.smsError}`);
  if (PROVIDERS.whatsappError && env('WHATSAPP_PROVIDER')) console.warn(`  WhatsApp: ${PROVIDERS.whatsappError}`);
  if (!env('NOTIFY_ALLOWED_ORIGIN')) console.warn('  Sem NOTIFY_ALLOWED_ORIGIN o navegador bloqueia os pedidos da app (use ex.: http://localhost:3000).');
  if (QUEUE_MODE) {
    const every = Math.max(5, Number(env('NOTIFY_POLL_SECONDS')) || 15) * 1000;
    setInterval(() => void drainQueue(), every);
    void drainQueue();
  }
});
