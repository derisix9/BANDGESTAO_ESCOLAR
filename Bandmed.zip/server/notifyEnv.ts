/**
 * Fornecedores de SMS/WhatsApp do worker global, escolhidos por variável de ambiente (ver o cabeçalho de server/notify.ts).
 * Parte pura (sem servidor), testada em tests/notificationProviders.test.ts.
 */
import {
  NotifyError, cleanSmsSetup, cleanWhatsAppSetup, isSmsProvider, isWhatsAppProvider, makeSmsProvider, makeWhatsAppProvider, secretMissing,
  type SmsProvider, type WhatsAppProvider
} from '../supabase/functions/_shared/notify';

export interface Providers { sms?: SmsProvider; whatsapp?: WhatsAppProvider; smsError?: string; whatsappError?: string }

/** Validados com as mesmas regras da configuração por escola. */
export function buildProvidersFromEnv(e: (k: string) => string = (k) => process.env[k] || ''): Providers {
  const out: Providers = {};
  try {
    const id = e('SMS_PROVIDER') || 'twilio';
    if (!isSmsProvider(id)) throw new NotifyError(`SMS_PROVIDER "${id}" não é suportado (twilio, infobip ou http).`);
    let c: Record<string, unknown> = {}, sec: Record<string, string> = {};
    if (id === 'twilio') { c = { from: e('TWILIO_SMS_FROM'), messagingServiceSid: e('TWILIO_MESSAGING_SERVICE_SID') }; sec = { accountSid: e('TWILIO_ACCOUNT_SID'), authToken: e('TWILIO_AUTH_TOKEN') }; }
    else if (id === 'infobip') { c = { baseUrl: e('INFOBIP_BASE_URL'), sender: e('INFOBIP_SENDER') }; sec = { apiKey: e('INFOBIP_API_KEY') }; }
    else {
      c = { url: e('SMS_HTTP_URL'), bodyTemplate: e('SMS_HTTP_BODY_TEMPLATE'), contentType: e('SMS_HTTP_CONTENT_TYPE'), authMode: e('SMS_HTTP_AUTH_MODE') || 'none',
            authName: e('SMS_HTTP_AUTH_NAME'), phoneFormat: e('SMS_HTTP_PHONE_FORMAT'), sender: e('SMS_HTTP_SENDER'), successContains: e('SMS_HTTP_SUCCESS_CONTAINS') };
      sec = { token: e('SMS_HTTP_TOKEN') };
    }
    const setup = cleanSmsSetup(id, { config: c, secret: sec });
    const missing = secretMissing('sms', id, setup.config, setup.secret);
    if (missing) throw new NotifyError(missing);
    out.sms = makeSmsProvider(id, setup.config, setup.secret);
  } catch (err) { out.smsError = err instanceof NotifyError ? err.message : 'Configuração de SMS inválida.'; }
  try {
    const id = e('WHATSAPP_PROVIDER') || 'twilio';
    if (!isWhatsAppProvider(id)) throw new NotifyError(`WHATSAPP_PROVIDER "${id}" não é suportado (twilio ou meta_cloud).`);
    if (id === 'twilio') {
      const sec = { accountSid: e('TWILIO_ACCOUNT_SID'), authToken: e('TWILIO_AUTH_TOKEN') };
      if (e('TWILIO_WHATSAPP_CONTENT_SID')) {
        const setup = cleanWhatsAppSetup('twilio', { config: { from: e('TWILIO_WHATSAPP_FROM'), contentSid: e('TWILIO_WHATSAPP_CONTENT_SID') }, secret: sec });
        const missing = secretMissing('whatsapp', id, setup.config, setup.secret);
        if (missing) throw new NotifyError(missing);
        out.whatsapp = makeWhatsAppProvider(id, setup.config, setup.secret);
      } else if (e('TWILIO_WHATSAPP_FROM')) {
        // Compatibilidade: texto livre (só no sandbox do Twilio). Em produção defina TWILIO_WHATSAPP_CONTENT_SID.
        out.whatsapp = makeWhatsAppProvider(id, { from: e('TWILIO_WHATSAPP_FROM'), freeform: true }, sec);
      } else throw new NotifyError('Falta TWILIO_WHATSAPP_FROM.');
    } else {
      const setup = cleanWhatsAppSetup('meta_cloud', { config: { phoneNumberId: e('META_PHONE_NUMBER_ID'), templateName: e('META_TEMPLATE_NAME'), templateLang: e('META_TEMPLATE_LANG'), apiVersion: e('META_API_VERSION') }, secret: { accessToken: e('META_ACCESS_TOKEN') } });
      const missing = secretMissing('whatsapp', id, setup.config, setup.secret);
      if (missing) throw new NotifyError(missing);
      out.whatsapp = makeWhatsAppProvider(id, setup.config, setup.secret);
    }
  } catch (err) { out.whatsappError = err instanceof NotifyError ? err.message : 'Configuração de WhatsApp inválida.'; }
  return out;
}

